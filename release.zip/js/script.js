window.homeClick = function () {
  alert(
    "vous allez acceder a la page d'acceuil du site educatif du groupe 8 B3 keyce informatique"
  );
};
window.elementClick = function () {
  alert(
    "vous allez acceder a la page elements ou l'on trouvera des elements utilise dans le site pour pendant votre progression educative"
  );
};
window.staffClick = function () {
  alert(
    "vous allez acceder a la page equipe ou l'on trouvera des informations sur les membres de l'equipe de developpement du site"
  );
};
window.newsClick = function () {
  alert(
    "vous allez acceder a la page actualites ou l'on trouvera des informations sur les dernieres nouvelles du site et de son equipe de developpement"
  );
};
window.galleryClick = function () {
  alert(
    "vous allez acceder a la page galerie ou l'on trouvera des images et des videos sur le site et son equipe de developpement"
  );
};
window.aboutClick = function () {
  alert(
    "vous allez acceder a la page a propos ou l'on trouvera des informations sur le site et son equipe de developpement"
  );
};
window.contactClick = function () {
  alert(
    "vous allez acceder a la page contact ou l'on trouvera des informations pour nous contacter en cas de besoin"
  );
};